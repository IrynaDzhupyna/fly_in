from __future__ import annotations
from typing import TYPE_CHECKING

from dataclasses import dataclass, field
from enum import Enum

from zone import Zone, Zone_role
from connection import Connection

if TYPE_CHECKING:
    from connection import Connection

class Drone_state(Enum):
    """ Describes the state of drones"""

    AVAILABLE = "available"
    WAITING = "waiting"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"


@dataclass
class Drone:
    """ Singular drone moving through the net"""

    id: int
    state: Drone_state
    current_zone: Zone
    current_connection: Connection | None = None
    # path stores the zones drone came from(history)
    # we can remove it later
    path: list[str] = field(default_factory=list, init=False)
    turns_taken: int = 0

    def move_to_zone(self, zone: Zone) -> None:
        self.current_zone = zone
        self.current_connection = None
        self.state = Drone_state.AVAILABLE
        self.path.append(zone.name)
        self.turns_taken += 1

    def move_to_connection(self, connection: Connection):
        self.current_connection = connection
        self.state = Drone_state.IN_TRANSIT
        self.turns_taken += 1

    # what happens when drone moved but not delvered
    def mark_delivered(self) -> None:
        if self.current_zone.role is Zone_role.END:
            self.state = Drone_state.DELIVERED

    def drone_info(self) -> None:
        print(f"Drone: D{self.id}\nState: {self.state}\n"
              f"Current zone: {self.current_zone}")
